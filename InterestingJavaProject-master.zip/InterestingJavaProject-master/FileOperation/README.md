Here are some interesting project mainly about File Operation.

Those are all by my brainstorm. Useful for java freshman.

So enjoy it. Come on.
