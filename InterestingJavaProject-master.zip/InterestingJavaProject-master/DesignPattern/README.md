## Details

Here are some good ideas for design pattern.

For details, here are some superlinks for you.
---
- <a href='http://blog.csdn.net/marksinoberg/article/details/51487570'>The Chain Of Responsibility</a>
