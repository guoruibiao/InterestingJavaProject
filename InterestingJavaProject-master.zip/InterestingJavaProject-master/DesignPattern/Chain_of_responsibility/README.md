Implements : The Chain Of Responsibility.
