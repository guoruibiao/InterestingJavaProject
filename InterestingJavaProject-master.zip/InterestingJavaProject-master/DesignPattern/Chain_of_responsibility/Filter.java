package ResponsibilityChain;

public interface Filter {

	public String doFilte(String message);

}
