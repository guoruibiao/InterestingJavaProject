
##Knoeledge Line
Here is the knowledge in my university class. So I listed them for memory.
