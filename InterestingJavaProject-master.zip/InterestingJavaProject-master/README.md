# InterestingJavaProject
There are some interesting projects made by java. Helpful for the freshman :-)
![Practice makes perfect](http://codecloud.b0.upaiyun.com/7cc829d3gw1exs.jpg)

### For File Operation(文件操作)

- Reverse the String you input.(反序输入的字符串，不使用Reverse()方法)
- Latina pig game.(拉丁猪小游戏)
- Count the vowels in the String you inputed.(统计输入的字符串中的元音字母的个数，精确到每一种有多少个)
- Encode and Decode your files.(最精简的加密程序，实现文件的编码以及解码，防止别人偷窥哦。)
- Palindrome , judge whether is Palindrome.(判断一个字符串是不是回文的)
- Words count. Both String and file, can count it.(统计一个字符串中，单词的数目。这里添加了统计一个文本文件中所有的单词数量的统计)
- Choose Helper.(一个借助于awt，Math.random(),以及各种布局和各种侦听事件处理的简单的小程序，帮助选择困难症做出比较合适的选择)
- Text parsed to HTML file.(支持换行，回车，<,>,以及TAB键等符号的小程序，可以将文本文件转换成浏览器可以解析的HTML格式的文件)

### For Awt_Swing 

- Choose Helper(可以较好的锻炼对于各种布局和各种侦听事件的处理能力；方便的帮助选择困难症做出比较合适的选择)

### For Network

- Something worth remember.(大学二年级时期的计算机网络，比较重要的理论性的知识点)

### For Algrithm 

- while there are some algrithm we may often use, so I make some demos in this folder.(既有自己的小算法，也有大拿们的经典)
